
public class ParkPlace {
	// Ebrar Çelikkaya , 150123067
	//This class is a template for the park places of each vehicle , based on their size.
	
	private int size;
	private Vehicle vehicle;

	
	
	public ParkPlace(Vehicle vehicle) {
		this.vehicle = vehicle;

	}

	public int getSize() {
		return size;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}
}
