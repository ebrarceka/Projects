
public class CarPark {
	// Ebrar Çelikkaya 150123067
	// This class is a template for a virtual car park, regulating tickets and park
	// places of each vehicle it contains.
	private int capacity;
	public ParkPlace[] parkPlaceArray;
	public Ticket[] ticketArray;
	private double hourlyPrice;
	private int index; // for keeping track of parkPlaceArray.

	public CarPark(int capacity, double hourlyPrice) {
		this.capacity = capacity;
		this.hourlyPrice = hourlyPrice;
		parkPlaceArray = new ParkPlace[capacity];
		ticketArray = new Ticket[capacity];

	}

	public Ticket parkVehicle(Vehicle vehicle, java.util.Date entryDate) {

		if (index + vehicle.getSize() <= capacity - 1) { // checking whether the vehicle fits or not

			Ticket ticket = new Ticket(vehicle, entryDate);

			ParkPlace parkplace = new ParkPlace(vehicle);
			parkPlaceArray[index] = parkplace;

			System.out.println("The vehicle with " + vehicle.getPlateNumber() + " plate number is parked.");

			index += vehicle.getSize();

			return (ticket);

		} else {
			System.out.println("Park is full.");

			return null;
		}

	}

	public Vehicle exitVehicle(Ticket ticket, java.util.Date exitDate) {

		for (int i = 0; i < parkPlaceArray.length; i++) {
			// searching our car by its plate number & deleting it from the array
			if (parkPlaceArray[i] != null
					&& ticket.getVehicle().getPlateNumber() == parkPlaceArray[i].getVehicle().getPlateNumber()) {

				ticket.calculatePrice(hourlyPrice, exitDate);

				System.out.println("The price for the vehicle with " + ticket.getVehicle().getPlateNumber()
						+ " plate number is : \n" + ticket.getPrice());

				ticketArray[Ticket.numberOfTickets] = ticket;

				parkPlaceArray[i] = null;

			}
		}
		// filtering the null places in our array and resizing it with the help of a
		// temporary array (temp).
		int nullCounter = 0;
		ParkPlace[] temp = new ParkPlace[capacity];
		for (int i = 0, j = 0; i < parkPlaceArray.length; i++, j++) {
			if (parkPlaceArray[i] == null) {
				j--;
				nullCounter++;
				continue;
			} else {
				temp[j] = parkPlaceArray[i];
			}

		}
		parkPlaceArray = new ParkPlace[capacity - nullCounter]; // resizing ,

		System.arraycopy(temp, 0, parkPlaceArray, 0, parkPlaceArray.length); // copying ,

		capacity = capacity - nullCounter; // updating the capacity !

		return ticket.getVehicle();

	}

	public double getTotalIncome() {

		double income = 0;

		for (int i = 0; i < ticketArray.length; i++) {
			if (ticketArray[i] != null) // i've had my fair share of nullPointerExceptions...
				income += ticketArray[i].getPrice();
		}
		return income;
	}

	public void printVehicleList() {

		System.out.println("_____VEHICLE LIST______\n\n");

		for (int i = 0; i < parkPlaceArray.length; i++) {
			if (parkPlaceArray[i] != null) {
				System.out.println(parkPlaceArray[i].getVehicle().getVehicleInfo());
				System.out.println("_________________");
			}

		}

	}

	public void printTickets() {

		System.out.println("_____TICKET LIST______\n\n");

		for (int i = 0; i < ticketArray.length; i++)
			if (ticketArray[i] != null) {
				System.out.println(ticketArray[i].getTicketInfo());
				System.out.println("_________________");
			}

	}

}
