
public class Vehicle {
	// Ebrar Çelikkaya , 150123067
	// This class is a template for Vehicles of our so-called Car Park, keeping
	// their plate numbers & sizes as data.
	private String plateNumber;
	private int size;

	public Vehicle(String plateNumber, int size) {
		this.plateNumber = plateNumber;
		this.size = size;

	}

	public String getPlateNumber() {
		return plateNumber;
	}

	public int getSize() {
		return size;
	}

	public String getVehicleInfo() {
		return "Vehicle Info \nPlate Number : " + plateNumber + "\nSize : " + size;
	}
}
