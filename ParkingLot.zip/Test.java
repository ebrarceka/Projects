
public class Test {
	// Ebrar Çelikkaya , 150123067
	// A test class to create CarPark , Ticket , Vehicle & ParkPlace objects and use
	// them.
	public static void main(String[] args) {
		CarPark myCarPark = new CarPark(10, 5);
		Vehicle v1 = new Vehicle("1ABC123", 4);
		Vehicle v2 = new Vehicle("2DEF123", 2);
		Vehicle v3 = new Vehicle("3GHI123", 1);
		Vehicle v4 = new Vehicle("4JKL123", 2);
		Vehicle v5 = new Vehicle("5YIL123", 4);

		// Setting up the dates according to each other , starting from the current
		// time.
		java.util.Date entryDate1 = new java.util.Date();

		java.util.Date entryDate2 = new java.util.Date();
		entryDate2.setTime(entryDate1.getTime() + 3600000);

		java.util.Date entryDate3 = new java.util.Date();
		entryDate3.setTime(entryDate2.getTime() + 3600000);

		java.util.Date entryDate4 = new java.util.Date();
		entryDate4.setTime(entryDate3.getTime() + 3600000);

		java.util.Date entryDate5 = new java.util.Date();
		entryDate5.setTime(entryDate4.getTime() + 3600000);

		java.util.Date exitDate1 = new java.util.Date();
		exitDate1.setTime(entryDate1.getTime() + 3600000 * 4);

		java.util.Date exitDate2 = new java.util.Date();
		exitDate2.setTime(entryDate1.getTime() + 3600000 * 5);

		java.util.Date exitDate3 = new java.util.Date();
		exitDate3.setTime(entryDate1.getTime() + 3600000 * 6);

		// parkVehicle method does a bunch of other things before returning the ticket.
		// We don't want them to reappear on the screen while invoking the exitVehicle
		// method , hence the assignments below.
		Ticket ticket1 = myCarPark.parkVehicle(v1, entryDate1);

		Ticket ticket2 = myCarPark.parkVehicle(v2, entryDate1);

		Ticket ticket3 = myCarPark.parkVehicle(v3, entryDate1);

		Ticket ticket4 = myCarPark.parkVehicle(v4, entryDate1);

		Ticket ticket5 = myCarPark.parkVehicle(v5, entryDate1);

		myCarPark.printVehicleList();

		System.out.println();

		myCarPark.exitVehicle(ticket1, exitDate1);
		myCarPark.exitVehicle(ticket4, exitDate2);

		System.out.println();

		myCarPark.printVehicleList();

		System.out.println();
		System.out.println();

		myCarPark.exitVehicle(ticket2, exitDate3);
		myCarPark.exitVehicle(ticket3, exitDate3);

		myCarPark.printVehicleList();

		System.out.println("Total income of the day was : " + myCarPark.getTotalIncome());
		System.out.println("The number of tickets was : " + Ticket.numberOfTickets);

		myCarPark.printTickets();

	}

}
