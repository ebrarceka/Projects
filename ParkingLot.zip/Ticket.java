
public class Ticket {
	// Ebrar Çelikkaya , 150123067
	private Vehicle vehicle;
	private java.util.Date entryDate;
	private java.util.Date exitDate;
	private double totalPrice;
	public static int numberOfTickets;

	public Ticket(Vehicle vehicle, java.util.Date entryDate) {
		this.vehicle = vehicle;
		this.entryDate = entryDate;
		numberOfTickets++;

	}

	public double calculatePrice(double hourlyPrice, java.util.Date exitDate) {
		this.exitDate = exitDate;
		totalPrice = vehicle.getSize() * hourlyPrice * Math.ceil((exitDate.getTime() - entryDate.getTime()) / 3600000);
		// getTime method gets us the milliseconds , so we do the needed conversions.
		return totalPrice;

	}

	public Vehicle getVehicle() {
		return vehicle;

	}

	public double getPrice() {
		return totalPrice;
	}

	public String getTicketInfo() {
		if (exitDate != null)
			return "Ticket Info \nPlate Number :  " + vehicle.getPlateNumber() + "\nEntry :" + entryDate + "\nExit : "
					+ exitDate + "\nHour : " + Math.ceil((exitDate.getTime() - entryDate.getTime()) / 3600000)
					+ "\nFee : " + totalPrice;
		else
			return "Ticket Info \nPlate Number :  " + vehicle.getPlateNumber() + "\nEntry : " + entryDate;
	}

}
