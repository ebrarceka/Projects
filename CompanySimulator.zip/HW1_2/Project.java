
public class Project {
private String projectName;
private java.util.Calendar startDate;
private boolean state;
public static java.util.ArrayList<Project> projects = new java.util.ArrayList<Project>();

public Project(String pName , java.util.Calendar startDate,String state) {
	projectName = pName;
	this.startDate = startDate;
	if(state.equalsIgnoreCase("Open")) {
		this.state =true;	
	}
	else {
		this.state =false;
	}
			
}


public void setState(String state ) {
	if(state.equalsIgnoreCase("Open"))
		this.state=true;
	else
		this.state=false;
}

public String getState() {
	if(this.state==true)
		return"Open ";
	else
		return "Close ";
}

public void close() {
	state =false;
}


public String getProjectName() {
	return projectName;
}


public void setProjectName(String projectName) {
	this.projectName = projectName;
}


public java.util.Calendar getStartDate() {
	return startDate;
}


public void setStartDate(java.util.Calendar startDate) {
	this.startDate = startDate;
}


@Override
public String toString() {
	return "Project [projectName=" + projectName + ", startDate=" + startDate + ", state=" + state + "]";
}


}
