import java.util.ArrayList;

public class Customer extends Person{
private java.util.ArrayList<Product> products ;

public Customer(int id ,String firstName , String lastName ,String gender ,java.util.Calendar birthDate, 
		 String maritalStatus, String hasDriverLicence, java.util.ArrayList products) {
	super(id,firstName,lastName,gender,birthDate,maritalStatus,hasDriverLicence);
	products = new java.util.ArrayList<Product>();
	
}
public Customer(Person person ,java.util.ArrayList<Product> products) {
	super(person.getId(),person.getFirstName(),person.getLastName(),person.getGender(),person.getBirthDate(),person.getMaritalStatus(),person.HasDriverLicence());
	products = new java.util.ArrayList<Product>();
	}
public java.util.ArrayList<Product> getProducts() {
	return products;
}
public void setProducts(java.util.ArrayList<Product> products) {
	this.products = products;
}
@Override
public String toString() {
	final int maxLen = 10;
	return "Customer [products=" + (products != null ? products.subList(0, Math.min(products.size(), maxLen)) : null)
			+ ", getProducts()="
			+ (getProducts() != null ? getProducts().subList(0, Math.min(getProducts().size(), maxLen)) : null)
			+ ", getId()=" + getId() + ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName()
			+ ", getGender()=" + getGender() + ", getBirthDate()=" + getBirthDate() + ", getMaritalStatus()="
			+ getMaritalStatus() + ", HasDriverLicence()=" + HasDriverLicence() + ", getClass()=" + getClass()
			+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}
}

