
public class Person {
 private int id ;
 private String firstName;
 private String lastName;
 private byte gender;
 private java.util.Calendar birthDate;
 private byte maritalStatus;
 private boolean hasDriverLicence;
public static java.util.ArrayList<Person> people= new java.util.ArrayList<>();
 
 public Person (int id ,String firstName , String lastName ,String gender ,java.util.Calendar birthDate, 
		 String maritalStatus, String hasDriverLicence) {
	
	 this.id =id;
	 this.firstName = firstName;
	 this.lastName = lastName;

	
	 if(gender.equalsIgnoreCase("woman")) {
	   this.gender = 1;
	 }
	 if(gender.equalsIgnoreCase("man")) {
       this.gender = 2;
	 }
      
	   this.birthDate=birthDate;
 
	   if(maritalStatus.equalsIgnoreCase("single")) {
		   this.maritalStatus = 1;
		 }
	   if(maritalStatus.equalsIgnoreCase("married")) {
	       this.maritalStatus= 2;
		 }
	   
	   if(hasDriverLicence.equalsIgnoreCase("yes")) {
		   this.hasDriverLicence = true;
		 }
	   if(hasDriverLicence.equalsIgnoreCase("no")) {
		   this.hasDriverLicence = false;
		 }
}


public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}


public String getFirstName() {
	return firstName;
}


public void setFirstName(String firstName) {
	this.firstName = firstName;
}


public String getLastName() {
	return lastName;
}


public void setLastName(String lastName) {
	this.lastName = lastName;
}


public String getGender() {
	
	if (gender ==1)
	return "Woman " ;
	
	else {
    return "Man" ;
	}
}


public void setGender(String gender) {
	if (gender.equalsIgnoreCase("woman"))
		this.gender=1;
	else {
		this.gender =2;
	}
}


public java.util.Calendar getBirthDate() {
	return birthDate;
}


public void setBirthDate(java.util.Calendar birthDate) {
	this.birthDate = birthDate;
}


public String getMaritalStatus() {
	if(maritalStatus==1)
	return "Single ";
	else {
	return "Married ";
	}
}


public void setMaritalStatus(String maritalStatus) {
	if (maritalStatus.equalsIgnoreCase("single"))
		this.maritalStatus=1;
	else {
		this.maritalStatus =2;
	}
}


public String HasDriverLicence() {
	if(hasDriverLicence==true) {
		return "Yes ";
	
	}
	else {
	    return "No ";
		}
	
}


public void setHasDriverLicence(String hasDriverLicence) {
	if(hasDriverLicence.equalsIgnoreCase("yes")) {
		this.hasDriverLicence=true;
	}
	else {
		this.hasDriverLicence=false;
	}

}


}