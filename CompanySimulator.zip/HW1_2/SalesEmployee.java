
public class SalesEmployee extends RegularEmployee {
	private java.util.ArrayList<Product> sales;
	public static int numberOfSalesEmployees;
	

	public SalesEmployee(int id ,String firstName , String lastName ,String gender ,java.util.Calendar birthDate, 
			 String maritalStatus, String hasDriverLicence,double salary,java.util.Calendar hireDate,Department department,double performanceScore, java.util.ArrayList<Product> s) {
		super(id,firstName,lastName,gender,birthDate,maritalStatus,hasDriverLicence,salary,hireDate,department,performanceScore);
	sales =s;
	sales =new java.util.ArrayList<Product>();
	numberOfSalesEmployees++;
	
	}
	
	public SalesEmployee(RegularEmployee re , java.util.ArrayList<Product>s) {
		super(re.getId(),re.getFirstName(),re.getLastName(),re.getGender(),re.getBirthDate(),
				  re.getMaritalStatus(),re.HasDriverLicence(),re.getSalary(),re.getHireDate(),re.getDepartment(),re.getPerformanceScore());
		sales =s;
		sales =new java.util.ArrayList<Product>();
		numberOfSalesEmployees++;
		
	}
	public boolean addSale(Product p) {
		if(sales.add(p))
			return true;
		else 
			return false;
	} 
	public boolean removeSale(Product p) {
		if(sales.remove(p))
		    return true;
        else
		    return false;
	}

	public java.util.ArrayList<Product> getSales() {
		return sales;
	}

	public void setSales(java.util.ArrayList<Product> sales) {
		this.sales = sales;
	}

	@Override
	public String toString() {
		return "SalesEmployee [sales=" + sales + "]";
	}




}
