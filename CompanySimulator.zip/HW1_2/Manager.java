
public class Manager extends Employee{
private java.util.ArrayList<RegularEmployee> regularEmployees;
private double bonusBudget;

public Manager (int id ,String firstName , String lastName ,String gender ,java.util.Calendar birthDate, 
		 String maritalStatus, String hasDriverLicence,double salary,java.util.Calendar hireDate,Department department,double bonusBudget) {
	super(id,firstName,lastName,gender,birthDate,maritalStatus,hasDriverLicence,salary,hireDate,department);
	this.bonusBudget=bonusBudget;
	regularEmployees = new java.util.ArrayList<RegularEmployee>();
}

public Manager(Employee employee,double bonusBudget) {
	super(employee.getId(),employee.getFirstName(),employee.getLastName(),employee.getGender(),employee.getBirthDate(),
			  employee.getMaritalStatus(),employee.HasDriverLicence(),employee.getSalary(),employee.getHireDate(),employee.getDepartment());
	this.bonusBudget=bonusBudget;
	regularEmployees= new java.util.ArrayList<RegularEmployee>();
}

public void addEmployee(RegularEmployee e ) {
	
	regularEmployees.add(e);
	
}

public void removeEmployee(RegularEmployee e ) {
	
   regularEmployees.remove(e);
	
}
//I DIDNT FINISH THIS PART!! FOR REVERANCE
public void distributeBonusBudget() {
 double unitSum =0;
	for(int i =0 ; i<regularEmployees.size();i++){
		unitSum +=regularEmployees.get(i).getSalary()*regularEmployees.get(i).getPerformanceScore();
	}
	double unit = bonusBudget/unitSum;
	
}

public java.util.ArrayList<RegularEmployee> getRegularEmployees() {
	return regularEmployees;
}

public void setRegularEmployees(java.util.ArrayList<RegularEmployee> regularEmployees) {
	this.regularEmployees = regularEmployees;
}

public double getBonusBudget() {
	return bonusBudget;
}

public void setBonusBudget(double bonusBudget) {
	this.bonusBudget = bonusBudget;
}

@Override
public String toString() {
	return "Manager [id=" + getId()
			+ getFirstName()+" " +getLastName()+ ",  # of Employees :" + Employee.numberOfEmployees+"]";
}


}
