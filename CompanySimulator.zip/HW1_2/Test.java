
import java.io.*;
import java.util.*;
public class Test {

	public static void main(String[] args) throws FileNotFoundException,IOException {
	java.util.ArrayList<Product> products = new java.util.ArrayList<>();
	java.util.ArrayList<Person> people= new java.util.ArrayList<>();
	java.util.ArrayList<Department> departments = new java.util.ArrayList<>();
	java.util.ArrayList<Project> projects = new java.util.ArrayList<>();
	java.util.ArrayList<String>projectNames = new java.util.ArrayList<>();
	java.util.ArrayList<String>productNames = new java.util.ArrayList<>();

	
		 
	File input = new File("HW1_2\\input.txt");
	PrintWriter file = new PrintWriter(input);
	file.print("Department 1 Accounting "
	        +"\nDepartment 2 Marketing"
			+"\nProject AutoCredit 01/05/2023 Open"
	        +"\nProject ATM 01/12/2023 Open"
			+"\nProject CreditCard 01/05/2022 Close"
			+"\nProject Robotic 01/05/2021 Open"
			+"\nProject LLM 01/07/2023 Open"
		    +"\nProject SpeechRecognition 01/09/2023 Open"
			+"\nProject MobilApp 01/11/2022 Open"
			+"\nProduct Product1 01/01/2023 10000"
			+"\nProduct Product2 01/02/2023 1500"
			+"\nProduct Product3 01/11/2023 15000"
			+"\nProduct Product4 01/04/2024 50000"
			+"\nProduct Product5 11/01/2023 90000"
			+"\nPerson Ayse Caliskan 111 Woman 05/05/1986 Married Yes"
			+"\nPerson Mehmet Ari 123 Man 09/06/1982 Single Yes"
			+"\nPerson Ismail Celik 145 Man 09/06/1988 Married Yes"
			+"\nPerson Bulut Karadag 156 Man 23/07/1979 Single Yes"
		    +"\nPerson Serkan Yildiz 167 Man 25/09/1990 Married Yes"
			+"\nPerson Cevdet Balci 178 Man 28/11/1988 Married No"
			+"\nPerson Taner Eser 189 Man 09/01/1967 Single Yes"
		    +"\nPerson Mustafa Emir 213 Man 05/04/1989 Married Yes"
			+"\nPerson Hacer Paksoy 224 Woman 01/02/1998 Married Yes"
			+"\nPerson Ela Kara 236 Woman 24/09/1989 Married No"
			+"\nPerson Fatma Esin 247 Woman 18/11/1976 Single Yes"
			+"\nPerson Arzu Ozturk 256 Woman 17/12/1967 Married Yes"
			+"\nPerson Selin Ergul 267 Woman 09/07/1988 Single No"
			+"\nEmployee 123 50000 22/05/2015 Accounting"
			+"\nManager 123 150000"
			+"\nEmployee 111 35000 10/10/2017 Accounting"
			+"\nRegularEmployee 111 25"
			+"\nEmployee 156 45000 15/11/2018 Accounting"
			+"\nRegularEmployee 156 75"
			+"\nDeveloper 111 CreditCard Robotic"
			+"\nEmployee 167 75000 14/02/2015 Accounting"
			+"\nRegularEmployee 167 50"
			+"\nSalesEmployee 167 Product5 Product1"
			+"\nCustomer 224 Product1 Product2 Product5"
			+"\nCustomer 267 Product3"
			+"\nEmployee 213 100000 24/05/2014 Marketing"
			+"\nRegularEmployee 213 100"
			+"\nSalesEmployee 213 Product1 Product2 Product3"
			+"\nEmployee 256 150000 24/05/2010 Marketing"
			+"\nManager 256 200000"
			+"\nEmployee 247 50000 04/11/2016 Marketing"
			+"\nRegularEmployee 247 80"
			+"\nDeveloper 247 LLM SpeechRecognition ATM"
			+"\nCustomer 178 Product2 Product3");

	file.close();
	

	
	Scanner scan = new Scanner (input);
	String s = scan.nextLine();
	while(scan.hasNext()) {
		String s1 = scan.next();
		switch(s1) {
		case "Person":
			String firstName =scan.next();
			String lastName = scan.next();
			int id = scan.nextInt();
			String gender = scan.next();
			String birthDate = scan.next();
			String maritalStatus = scan.next();
			String hasDriverLicence = scan.next();
			
			Person person = new Person (id, firstName,lastName,gender,calendar(birthDate),maritalStatus,hasDriverLicence);
			Person.people.add(person);
	
			break;
			
			
			
		case "Product":
			String productName = scan.next();
			String saleDate = scan.next();
			double price = scan.nextDouble();
			
			Product product = new Product(productName, calendar(saleDate),price);
			products.add(product);
			productNames.add(productName);
			
			break;
			
			
			
			
		case "Customer":
		int customerId= scan.nextInt();
		java.util.ArrayList<Product>productArraylist = new java.util.ArrayList<>();
		while(productNames.contains(scan.next())) {
				String name = scan.next();
				productArraylist.add((Product)findMyProduct(name,products));
			
			}

			
			break;
			
		case "Project":
			String projectName=scan.next();
			String date=scan.next();
            String state= scan.next();
            Project project = new Project(projectName,calendar(date),state);
            projects.add(project);
            projectNames.add(projectName);

			break;
			
			
		
		case "Employee" : 
			int employeeId = scan.nextInt();
			int salary = scan.nextInt();
            String hireDate = scan.next();
            Person temp = (Person)(findMyPerson(employeeId,people));
            Department department1=(Department)(findMyDepartment(scan.next(),departments));
            if(temp!=null) {
		   Employee employee = new Employee(temp,salary,calendar(hireDate),department1);
		   }
		
			break;
		
		
		case "Department":
			int departmentId = scan.nextInt();
			String departmentName = scan.next();
            Department department = new Department(departmentId,departmentName);
            Department.departments.add(department);
			
            break;
            
            
            
		case "RegularEmployee":
			int regEmployeeId= scan.nextInt();
			Employee employee1= (Employee)(findMyPerson(regEmployeeId,people));
			int perfScore1 = scan.nextInt();
			if(employee1 !=null) {
			RegularEmployee regularEmployee = new RegularEmployee(employee1,perfScore1);
			}
			break;
			
			
	    case "Manager" : 
	    	int managerId= scan.nextInt();
			Employee employee2= (Employee)(findMyPerson(managerId,people));
			int perfScore2 = scan.nextInt();
			if(employee2!=null) {
			Manager manager = new Manager(employee2,perfScore2);
			}
			break;
			
		case "SalesEmployee" : 
			int salesEmployeeId= scan.nextInt();
			java.util.ArrayList<Product>arraylist1= new java.util.ArrayList<>();
			while(productNames.contains(scan.next()))  {
				String name = scan.next();
			
				arraylist1.add((Product)findMyProduct(name,products));
			
			}
			RegularEmployee rEmployee =(RegularEmployee)(findMyPerson(salesEmployeeId,people));
			if(rEmployee!=null) {
		SalesEmployee salesEmployee = new SalesEmployee(rEmployee,arraylist1);
			}
				
			break;
     	case "Developer" :
		int tempId= scan.nextInt();
		java.util.ArrayList<Project>arraylist2 = new java.util.ArrayList<>();
		while(projectNames.contains(scan.next())) {
			String name = scan.next();
			arraylist2.add((Project)findMyProject(name,projects));
		
		}
		RegularEmployee rEmployee2 =(RegularEmployee)(findMyPerson(tempId,people));
		if(rEmployee2 !=null) {
		Developer developer = new Developer (rEmployee2,arraylist2);
		}
		
			
			break;
		
		default : break;
		
		}
		}
		
	
	
	
	
	//ADDITIONAL METHODS
	File output = new File("HW1_2\\output.txt");
	PrintWriter outputFile = new PrintWriter(output);
     
    		 for(int i =0; i<departments.size();i++) {
    		  java.util.ArrayList<Person>[]array= classifier(gatherEmployees(departments.get(i),people));
    		outputFile.print(departments.get(i)+"\n\t"+findMyManager(departments.get(i),people)+"\n\t\t\t"+array[0]!=null ?"1.Developer" :(array[1]!=null? "1.Sales Employee" :(array[2]!=null?"1.RegularEmployee":"No Employees"))
    				+"\n\t\t\t\t");	
    		if(array[0]!=null) {
    			for(int j =0; j<array[0].size();j++) {
    				Person p = array[0].get(j);
    				outputFile.print((Person)p +"\n\t\t\t\t"+(Employee)p+"\n\t\t\t\t"+(RegularEmployee)p);
    			}
    		}
    		if(array[0]==null &&array[1]!=null) {
    			for(int j =0; j<array[1].size();j++) {
    				Person p = array[1].get(j);
    				outputFile.print((Person)p +"\n\t\t\t\t"+(Employee)p+"\n\t\t\t\t"+(RegularEmployee)p);
    			}
    			
    		}
    		if(array[0]==null &&array[2]==null&&array[2]!=null) {
    			for(int j =0; j<array[2].size();j++) {
    				Person p = array[2].get(j);
    				outputFile.print((Person)p +"\n\t\t\t\t"+(Employee)p+"\n\t\t\t\t"+(RegularEmployee)p);
    			}
    			
    		}
    		
    		outputFile.print("\n\t\t\t"+array[0]!=null ? (array[1]!=null? "2.Sales Employee" : (array[2]!=null? "2.Regular Employee" :"")) :(array[1]!=null ? (array[2]!=null? "2.Regular Employee" :""):"") );
    		
    		 if(array[0]!=null&&array[1]!=null) {
    			 for(int j =0; j<array[1].size();j++) {
  				Person p = array[1].get(j);
  				outputFile.print((Person)p +"\n\t\t\t\t"+(Employee)p+"\n\t\t\t\t"+(RegularEmployee)p);
  			}
 				 
 			 }
    		 if(array[0]==null &&array[1]!=null &&array[2]!=null) {
    			 for(int j =0; j<array[2].size();j++) {
     				Person p = array[2].get(j);
     				outputFile.print((Person)p +"\n\t\t\t\t"+(Employee)p+"\n\t\t\t\t"+(RegularEmployee)p);
     			}
    			 
    		 }
    		 outputFile.print("\n\t\t\t"+(array[0]!=null &&array[1]!=null ? "3.Regular Employee" :""));
    		 
    		 if(array[0]!=null && array[1]!=null && array[2]!=null) {
    			 for(int j =0; j<array[2].size();j++) {
      				Person p = array[2].get(j);
      				outputFile.print((Person)p +"\n\t\t\t\t"+(Employee)p+"\n\t\t\t\t"+(RegularEmployee)p);
      			}
    			 
    		 }
    		 outputFile.print("\n****************************************************************\n");
    		 
    		 }
    		 outputFile.close();
    		 }
    
    		
		
	

	
	
	
	
	
	public static Calendar calendar(String date) {
		int index =0;
		int a = 0;
		String[] tempArray= new String[3];
		
		while(a<date.length()) {
			if(date.charAt(a)=='/') {
				index++;
				}
			else {
				tempArray[index]+= date.charAt(a);
			}
			a++;
		}
		
		Calendar cal = Calendar.getInstance();
	    
	    cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(tempArray[0].substring(4)));
	    cal.set(Calendar.MONTH, Integer.parseInt(tempArray[1].substring(4)));
	    cal.set(Calendar.YEAR, Integer.parseInt(tempArray[2].substring(4)));
		
		return cal;
	}
	

	
	public static Object findMyPerson(int id,java.util.ArrayList<Person> people) {
	
	for(int i=0; i<people.size();i++) {
		if(people.get(i).getId()==id)
			return people.get(i);
	}
		return null;
	
	}
	
	public static Object findMyDepartment(String name, java.util.ArrayList<Department> departments) {
		for(int i=0; i<departments.size();i++) {
			if(departments.get(i).getDepartmentName().equals(name))
				return departments.get(i);
		}
			return null;
		
	}
	public static Object findMyProject(String name, java.util.ArrayList<Project> projects) {
		for(int i=0;i<projects.size();i++) {
			if(projects.get(i).getProjectName().equals(name))
				return projects.get(i);
		}
		return null;
	}
	public static Object findMyProduct(String name, java.util.ArrayList<Product> products) {
		for(int i=0;i<products.size();i++) {
			if(products.get(i).getProductName().equals(name))
				return products.get(i);
		}
		return null;
	}
	
	public static Manager findMyManager(Department department, java.util.ArrayList<Person> people) {
		for(int i =0; i<people.size() ;i++) {
			if(people.get(i) instanceof Manager && ((Employee)people.get(i)).getDepartment().getDepartmentName().equals(department.getDepartmentName())) {
				return (Manager)people.get(i);
			}
			
		}
		return null;
	}
	
	public static java.util.ArrayList<Person> gatherEmployees (Department department,java.util.ArrayList<Person> people ) {
	java.util.ArrayList<Person> tempPerson = new java.util.ArrayList<Person>();
		for(int i =0; i<people.size();i++) {
			if(people.get(i) instanceof Employee)
				if(((Employee)people.get(i)).getDepartment().getDepartmentName().equals(department)) {
					tempPerson.add(people.get(i));
				}
		}
		return tempPerson;
		
	}
	public static java.util.ArrayList<Person>[] classifier(java.util.ArrayList<Person> people){
		java.util.ArrayList<Person>[] array= new java.util.ArrayList[3];
		java.util.ArrayList<Person> developers = new java.util.ArrayList<>();
		java.util.ArrayList<Person> sEmployees = new java.util.ArrayList<>();
		java.util.ArrayList<Person> rEmployees = new java.util.ArrayList<>();
		for(int i=0;i<people.size();i++) {
			
			if(people.get(i) instanceof Developer) {
				developers.add(people.get(i));
			}
			else if (people.get(i) instanceof SalesEmployee) {
				sEmployees.add(people.get(i));
			}
			else if(people.get(i) instanceof RegularEmployee) {
				rEmployees.add(people.get(i));
			}
		}
		if(!developers.isEmpty()) {array[0]=developers;
			
		}
		if(!sEmployees.isEmpty()) {array[1]=sEmployees;}
		if(!rEmployees.isEmpty()) {array[2]=rEmployees;}
		
		return array;
	
	}
	
}
	


