import java.util.Calendar;
import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		System.out.println("Enter a calendar in DAY/MONTTH/YEAR:");
		String s = scan.nextLine();
		System.out.println(calendar(s));

	}
	public static Calendar calendar(String date) {
		int index =0;
		int a = 0;
		String[] tempArray= new String[3];
		
		while(a<date.length()) {
			if(date.charAt(a)=='/') {
				index++;
				}
			else {
				if(Character.isDigit(date.charAt(a))){
				tempArray[index]+= date.charAt(a);
				}
			}
			a++;
			}
			
			Calendar cal = Calendar.getInstance();
		    
		    cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(tempArray[0].substring(4)));
		    cal.set(Calendar.MONTH, Integer.parseInt(tempArray[1].substring(4)));
		    cal.set(Calendar.YEAR, Integer.parseInt(tempArray[2].substring(4)));
			
			return cal;
		}
		
		
	}
