
public class Developer extends RegularEmployee {
	private java.util.ArrayList<Project> projects;
	public static int numberOfDevelopers;
	 
	public Developer(int id ,String firstName , String lastName ,String gender ,java.util.Calendar birthDate, 
			 String maritalStatus, String hasDriverLicence,double salary,java.util.Calendar hireDate,Department department,double performanceScore, java.util.ArrayList<Project> p) {
		super(id,firstName,lastName,gender,birthDate,maritalStatus,hasDriverLicence,salary,hireDate,department,performanceScore);
		projects =p;
		projects= new java.util.ArrayList<Project>();
		numberOfDevelopers++;
	}
	
	public Developer(RegularEmployee re , java.util.ArrayList<Project>p) {
		super(re.getId(),re.getFirstName(),re.getLastName(),re.getGender(),re.getBirthDate(),
				  re.getMaritalStatus(),re.HasDriverLicence(),re.getSalary(),re.getHireDate(),re.getDepartment(),re.getPerformanceScore());
		projects =p;
		projects= new java.util.ArrayList<Project>();
		numberOfDevelopers++;
	}

	
	public boolean addProject(Project s ) {
		if(projects.add(s))
			return true;
		else 
			return false;
	}
	
	public boolean removeProject(Project s) {
		if(projects.remove(s))
			return true ;
		else
			return false;
	}

	public java.util.ArrayList<Project> getProjects() {
		return projects;
	}

	public void setProjects(java.util.ArrayList<Project> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "Developer [projects=" + projects + "]";
	}
	
}
